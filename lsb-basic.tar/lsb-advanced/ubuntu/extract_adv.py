import wave
import sys
import random

def extract_advanced(audio_in, password, text_out):
    print("[*] Đang quét bộ nhớ âm thanh để tìm dữ liệu...")
    try:
        wav = wave.open(audio_in, mode='rb')
        frames = bytearray(list(wav.readframes(wav.getnframes())))
        
        # 1. KHÔI PHỤC BỘ SINH SỐ NGẪU NHIÊN
        # Phải dùng đúng Password thì vị trí random mới khớp với lúc giấu
        random.seed(password)
        indices = list(range(len(frames)))
        random.shuffle(indices)
        
        bits = ""
        enc_chars = []
        
        # 2. TRÍCH XUẤT VÀ GIẢI MÃ LIÊN TỤC
        for i in range(len(frames)):
            # Lấy LSB tại vị trí ngẫu nhiên
            bits += str(frames[indices[i]] & 1)
            
            # Cứ gom đủ 8 bit thì dịch ngược 1 ký tự
            if len(bits) == 8:
                enc_chars.append(chr(int(bits, 2)))
                bits = ""
                
                # Giải mã XOR thử xem có ra cờ kết thúc '###' không
                decrypted = ''.join(chr(ord(c) ^ ord(password[j % len(password)])) for j, c in enumerate(enc_chars))
                if decrypted.endswith("###"):
                    with open(text_out, 'w') as f:
                        f.write(decrypted[:-3])
                    print(f"[+] BINGO! Lấy cờ thành công. Kết quả lưu tại: {text_out}")
                    return
                    
        print("[-] THẤT BẠI: Sai mật khẩu hoặc file không chứa cờ!")
        
    except Exception as e:
        print("[-] Lỗi hệ thống:", str(e))

if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Cú pháp: python3 extract_adv.py <wav_da_giau> <mat_khau> <txt_ra>")
    else:
        extract_advanced(sys.argv[1], sys.argv[2], sys.argv[3])
