import wave
import sys
import random

def hide_advanced(audio_in, text_in, password, audio_out):
    print("[*] Đang khởi động tiến trình giấu tin nâng cao...")
    try:
        # Đọc file âm thanh
        wav = wave.open(audio_in, mode='rb')
        frames = bytearray(list(wav.readframes(wav.getnframes())))
        
        # Đọc thông điệp
        with open(text_in, 'r') as f:
            message = f.read() + "###" # Cờ kết thúc
            
        # 1. MÃ HÓA XOR (Pre-Encryption)
        encrypted = ''.join(chr(ord(c) ^ ord(password[i % len(password)])) for i, c in enumerate(message))
        
        # Chuyển thành chuỗi nhị phân
        bits = ''.join([format(ord(c), "08b") for c in encrypted])
        
        if len(bits) > len(frames):
            print("[-] Lỗi: File âm thanh quá ngắn!")
            return
            
        # 2. PHÂN TÁN BIT NGẪU NHIÊN
        # Dùng password làm seed để trộn danh sách vị trí
        random.seed(password)
        indices = list(range(len(frames)))
        random.shuffle(indices)
        
        # Giấu bit vào các vị trí đã bị xáo trộn
        for i, bit in enumerate(bits):
            idx = indices[i]
            frames[idx] = (frames[idx] & 254) | int(bit)
            
        # Xuất file
        with wave.open(audio_out, 'wb') as fd:
            fd.setparams(wav.getparams())
            fd.writeframes(bytes(frames))
        print("[+] SUCCESS! Thông điệp đã được mã hóa và băm nát vào file:", audio_out)
        
    except Exception as e:
        print("[-] Lỗi hệ thống:", str(e))

if __name__ == "__main__":
    if len(sys.argv) != 5:
        print("Cú pháp: python3 hide_adv.py <wav_goc> <txt_vao> <mat_khau> <wav_ra>")
    else:
        hide_advanced(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4])
