import wave, random, struct
with wave.open('original.wav', 'w') as f:
    f.setnchannels(1); f.setsampwidth(2); f.setframerate(44100)
    for _ in range(44100 * 3):
        f.writeframes(struct.pack('<h', random.randint(-32767, 32767)))
print("[+] Đã tạo file original.wav")
