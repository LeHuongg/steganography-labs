import wave
import sys

def extract_data(audio_in, text_out):
    try:
        wav = wave.open(audio_in, mode='rb')
        frame_bytes = bytearray(list(wav.readframes(wav.getnframes())))
        
        # Lấy toàn bộ bit LSB
        extracted_bits = [str(frame_bytes[i] & 1) for i in range(len(frame_bytes))]
        
        secret = ""
        # Ráp 8 bit thành 1 ký tự ASCII
        for i in range(0, len(extracted_bits), 8):
            byte = "".join(extracted_bits[i:i+8])
            secret += chr(int(byte, 2))
            # Dừng lại khi gặp cờ kết thúc '###'
            if secret.endswith("###"):
                secret = secret[:-3]
                break
                
        # Ghi kết quả ra file
        with open(text_out, 'w') as f:
            f.write(secret)
        print("[+] Trích xuất thành công! Hãy kiểm tra nội dung file:", text_out)
        
    except Exception as e:
        print("[-] Có lỗi xảy ra:", str(e))

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Cú pháp: python3 extract.py <audio_da_giau.wav> <file_ket_qua.txt>")
    else:
        extract_data(sys.argv[1], sys.argv[2])
