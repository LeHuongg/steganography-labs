import wave
import random
import struct

print("Đang tạo file original.wav, vui lòng đợi vài giây...")

# Khởi tạo file WAV chuẩn PCM (Mono, 16-bit, 44.1kHz)
with wave.open('original.wav', 'w') as wav_file:
    wav_file.setnchannels(1)       
    wav_file.setsampwidth(2)       
    wav_file.setframerate(44100)   
    
    # Sinh dữ liệu âm thanh ngẫu nhiên cho 3 giây
    for _ in range(44100 * 3):
        value = random.randint(-32767, 32767)
        wav_file.writeframes(struct.pack('<h', value))

print("[+] Đã tạo xong file original.wav chuẩn PCM không nén!")
