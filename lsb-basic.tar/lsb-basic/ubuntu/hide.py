import wave
import sys

def hide_data(audio_in, text_in, audio_out):
    try:
        # Đọc file âm thanh gốc
        wav = wave.open(audio_in, mode='rb')
        frame_bytes = bytearray(list(wav.readframes(wav.getnframes())))
        
        # Đọc thông điệp bí mật và thêm cờ kết thúc '###'
        with open(text_in, 'r') as f:
            secret = f.read() + "###"
            
        # Chuyển thông điệp thành chuỗi nhị phân
        secret_bits = ''.join([format(ord(i), "08b") for i in secret])
        
        if len(secret_bits) > len(frame_bytes):
            print("[-] Lỗi: File âm thanh quá ngắn để chứa thông điệp này!")
            return
            
        # Thuật toán thay thế bit LSB
        for i in range(len(secret_bits)):
            frame_bytes[i] = (frame_bytes[i] & 254) | int(secret_bits[i])
            
        # Ghi ra file âm thanh mới
        with wave.open(audio_out, 'wb') as fd:
            fd.setparams(wav.getparams())
            fd.writeframes(bytes(frame_bytes))
        print("[+] Giấu tin thành công vào file:", audio_out)
        
    except Exception as e:
        print("[-] Có lỗi xảy ra:", str(e))

if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Cú pháp: python3 hide.py <audio_goc.wav> <file_van_ban.txt> <audio_dau_ra.wav>")
    else:
        hide_data(sys.argv[1], sys.argv[2], sys.argv[3])
